module.exports={
  "development": {
    "username": "root",
    "password": "",
    "database": "chatterbox",
    "host": "127.0.0.1",
    "dialect": "mysql"
  },
  "test": {
    "username": "root",
    "password": null,
    "database": "database_test",
    "host": "127.0.0.1",
    "dialect": "mysql"
  },
  "production": {
    "username": "intevxxe_chatterbox",
    "password": "(@I!)yNFh%IN",
    "database": "intevxxe_chatterbox",
    "host": "127.0.0.1",
    "dialect": "mysql"
  }
}
